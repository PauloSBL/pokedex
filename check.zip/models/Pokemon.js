const { DataTypes } = require('sequelize')
const conn = require('./conn')

const Pokemon = conn.define('pokemon', {
    idPokemon: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
    nome: {
      type: DataTypes.STRING,
      require:true
    },
    img: {
      type: DataTypes.STRING,
      require:true
    },
    spd: {
      type: DataTypes.STRING
    },
    atk: {
      type: DataTypes.STRING
    },
    def: {
      type: DataTypes.STRING
    },
    type: {
      type: DataTypes.STRING
    },
    vantagens: {
      type: DataTypes.STRING
    },
  });
  
  module.exports = Pokemon