const { DataTypes } = require('sequelize')
const conn = require('./conn')

const User = conn.define('user', {
    id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
    usuario: {
      type: DataTypes.STRING,
      require:true
    },
    senha: {
      type: DataTypes.STRING,
      require:true
    },
    pokemon: {
      type: DataTypes.STRING
    },
  });
  
  module.exports = User