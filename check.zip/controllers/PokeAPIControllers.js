const request = require('request');
const Pokemon = require('../models/Pokemon')



module.exports = class PokeAPI{
    static addPokemon(req, res){
        console.log('finalizado')
        try{
            const { search } = req.body;
            const url = `https://pokeapi.co/api/v2/pokemon/${search}`;
        
            request.get(url, (error, response, body) => {
            if (error) {
                console.error(error)
                res.render('error')
                return;
            }
        
            const data = JSON.parse(body);
            res.render('addpokemon', { data })
            });

        }catch(err){
            console.log(err)
            const data = null
            res.render('addpokemon')
        }
    }
}