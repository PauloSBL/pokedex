const User = require('../models/User')
const Pokemon = require('../models/Pokemon')

const bcrypt = require('bcryptjs')


module.exports = class UserController{
    static login(req, res){
        res.render('login')
    }

    static async loginEnter(req, res){
        const { usuario , senha } = req.body

        // find user
        const user = await User.findOne({ where: { usuario:usuario } })
    
        if (!user) {
          res.render('login')
    
          return
        }
        

        // compare password
        const passwordMatch = bcrypt.compareSync(senha, user.senha)
        if (!passwordMatch) {
          res.render('login')
    
          return
        }
    
        // auth user
        req.session.userid = user.id
        //console.log(`----- aqui: ${req.session}`)

        req.session.save(() => {
          res.redirect('/')
        }) 
    }

    //CRUD USER

    static createUser(req, res){
        res.render('singup')
    }
   
    static async createUserSave(req,res){
        const salt = bcrypt.genSaltSync(10)
        const hashedPassword = await bcrypt.hashSync(req.body.senha, salt)
        const password = req.body.senha
        
        const formAdd = {
            usuario:req.body.usuario,
            senha:hashedPassword
        }

        let confirma = req.body.senhaConfirm

        try{
            if(confirma == password){
                await User.create(formAdd)
                res.redirect('/')
            }else{
                console.log('senha errada')
            }

        }catch(err){
            console.log(err)
        }
    }

    static async removeUser(req,res){
        const id = req.body.id
        await User.destroy({where:{id:id}})        
        res.redirect('/')
    }

    static async editPokemon(req,res){
        const id = req.params.id
        const poke = await Pokemon.findOne({where: {idPokemon:id}, raw:true})
        res.render('editPokemon',{poke})
    }

    static async editPokemonSave(req,res){
        const id = req.body.id
        console.log(id)
        console.log(req.body.nome)
        const pokeUpdate = {
            nome:req.body.nome
        }

        await Pokemon.update(pokeUpdate, {where:{idPokemon:id}})
        res.redirect('/')
    }

    static async showPokemons(req,res){
        const poke = await Pokemon.findAll({raw:true})
        const size = Object.keys(poke).length;
        res.render('home', {poke, size})
    }

    static addPokemon(req, res){
        res.render('addpokemon')
    }

}