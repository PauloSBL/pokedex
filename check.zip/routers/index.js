const express = require('express')
const router = express.Router()

const TaskController = require('../controllers/UsersControllers')
const PokeAPI = require('../controllers/PokeAPIControllers')

const checkAuth = require('../check/checkId').checkAuth

router.get('/',checkAuth ,TaskController.showPokemons)
router.get('/singup', TaskController.createUser)
router.post('/singup', TaskController.createUserSave)
router.post('/removeuser', TaskController.removeUser)
router.get('/login', TaskController.login)
router.get('/addpokemon', TaskController.addPokemon)
router.post('/addpokemon', PokeAPI.addPokemon)
router.post('/login', TaskController.loginEnter)

module.exports = router